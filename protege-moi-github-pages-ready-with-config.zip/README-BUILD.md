# Build & Minify (Vite)
- Dev: `npm i` puis `npm run dev`
- Build minifié: `npm run build` → produit `/dist` (JS/CSS/HTML minifiés)
- Preview build: `npm run preview`

Le service worker `firebase-messaging-sw.js` est servi depuis la racine du site (public). Si tu héberges via Firebase Hosting, place-le à la racine du domaine.
